from django.contrib import admin
from billboard.models import *

# Register your models here.
admin.site.register(MyUser)
admin.site.register(Agenda)
admin.site.register(Activity)
admin.site.register(Stage)